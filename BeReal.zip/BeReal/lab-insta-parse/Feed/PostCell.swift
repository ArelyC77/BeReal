//
//  PostCell.swift
//  lab-insta-parse
//
//  Created by Charlie Hieger on 11/3/22.
//

import UIKit
import Alamofire
import AlamofireImage

class PostCell: UITableViewCell {

    @IBOutlet private weak var usernameLabel: UILabel!
    @IBOutlet private weak var postImageView: UIImageView!
    @IBOutlet private weak var captionLabel: UILabel!
    @IBOutlet private weak var dateLabel: UILabel!
    @IBOutlet private weak var userInitialsView: UserInitialsView!
    
    private var imageDataRequest: DataRequest?
    

    func configure(with post: Post) {
        // TODO: Pt 1 - Configure Post Cell
        // Username
        if let user = post.user {
            usernameLabel.text = user.username
        }
        
        

        // Image
        if let imageFile = post.imageFile,
           let imageUrl = imageFile.url {
            
            // Use AlamofireImage helper to fetch remote image from URL
            imageDataRequest = AF.request(imageUrl).responseImage { [weak self] response in
                switch response.result {
                case .success(let image):
                    // Set image view image with fetched image
                    self?.postImageView.image = image
                case .failure(let error):
                    print("❌ Error fetching image: \(error.localizedDescription)")
                    break
                }
            }
        }

        // Caption
        captionLabel.text = post.caption

        // Date
        if let date = post.createdAt {
            dateLabel.text = DateFormatter.postFormatter.string(from: date)
        }
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        // TODO: P1 - Cancel image download
        // Reset image view image.
        postImageView.image = nil

        // Cancel image request.
        imageDataRequest?.cancel()
    }
    
    class UserInitialsView: UIView {
        
        private let initialsLabel: UILabel = {
            let label = UILabel()
            label.textAlignment = .center
            label.textColor = .white
            label.font = UIFont.systemFont(ofSize: 20, weight: .medium)
            return label
        }()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            setupViews()
        }
        
        required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            setupViews()
        }
        
        private func setupViews() {
            addSubview(initialsLabel)
            initialsLabel.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                initialsLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
                initialsLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
            ])
            layer.cornerRadius = frame.width / 2
            clipsToBounds = true
        }
        
        func configure(with username: String) {
            let initials = username
                .components(separatedBy: " ")
                .compactMap { $0.first }
                .prefix(2)
                .map { String($0) }
                .joined()
                .uppercased()
            initialsLabel.text = initials
            backgroundColor = UIColor(red: 0.2, green: 0.4, blue: 0.6, alpha: 1.0) // Customize background color
        }
    }
    
    
}
