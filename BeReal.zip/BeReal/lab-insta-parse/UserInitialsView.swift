//
//  UserInitialsView.swift
//  lab-insta-parse
//
//  Created by Arely Correa on 2/26/24.
//

import Foundation
import UIKit

import UIKit

class UserInitialsView: UIView {
    
    private let initialsLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 20, weight: .medium)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupViews()
    }
    
    private func setupViews() {
        addSubview(initialsLabel)
        initialsLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            initialsLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            initialsLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
        layer.cornerRadius = frame.width / 2
        clipsToBounds = true
    }
    
    func configure(with username: String) {
        let initials = username
            .components(separatedBy: " ")
            .compactMap { $0.first }
            .prefix(2)
            .map { String($0) }
            .joined()
            .uppercased()
        initialsLabel.text = initials
        backgroundColor = UIColor(red: 0.2, green: 0.4, blue: 0.6, alpha: 1.0) // Customize background color
    }
}

